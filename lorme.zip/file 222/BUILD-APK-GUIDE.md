# 📱 Build Lorme Android APK - Complete Guide

## 🎯 Quick Start (3 Methods)

---

## Method 1: EASIEST - No Android Studio Needed (10 minutes) ⭐⭐⭐⭐⭐

### What You Need:
- Node.js installed
- Internet connection
- 10 minutes

### Step-by-Step:

```bash
# 1. Navigate to android folder
cd android

# 2. Make gradlew executable (Mac/Linux only)
chmod +x gradlew

# 3. Build the APK
./gradlew assembleDebug      # Mac/Linux
gradlew assembleDebug        # Windows
```

### APK Location:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### Install on Phone:
1. Transfer APK to your phone
2. Enable "Install from Unknown Sources"
3. Tap APK to install
4. Done! 🎉

---

## Method 2: Using Android Studio (Visual - Recommended for First Time)

### What You Need:
- Android Studio (Download: https://developer.android.com/studio)
- ~3GB download
- 15-30 minutes setup

### Step-by-Step:

1. **Open Android Studio**
2. **Open Project**: Select the `android` folder
3. **Wait for Gradle Sync** (first time takes 5-10 minutes)
4. **Build APK**:
   - Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Or press: `Ctrl + F9` (Windows) / `Cmd + F9` (Mac)
5. **Find APK**: Click "locate" when build completes

### APK Location:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Method 3: PWA Builder (No Build Tools - 5 minutes)

### What You Need:
- Web hosting (or use Netlify Drop - free)

### Step-by-Step:

1. **Upload Web App**:
   ```bash
   # Go to: https://app.netlify.com/drop
   # Drag the 'dist' folder
   # Get your URL (e.g., https://lorme-app.netlify.app)
   ```

2. **Convert to APK**:
   ```bash
   # Go to: https://www.pwabuilder.com
   # Enter your URL
   # Click "Package for Android"
   # Download APK
   ```

3. **Install**: Transfer to phone and install!

---

## 📋 Prerequisites

### For Method 1 & 2 (Native Build):

**Required:**
- ✅ Node.js 16+ (https://nodejs.org)
- ✅ Java JDK 17 (https://adoptium.net)
- ✅ Android SDK (via Android Studio or command line)

**Optional but Recommended:**
- Android Studio (https://developer.android.com/studio)

### For Method 3 (PWA Builder):
- ✅ Just a web browser
- ✅ Free hosting account (Netlify, Vercel, GitHub Pages)

---

## 🔧 Setup Instructions

### First Time Setup (Method 1 & 2):

**1. Install Java JDK 17:**
```bash
# Windows: Download from https://adoptium.net
# Mac: brew install --cask temurin17
# Linux: sudo apt install openjdk-17-jdk
```

**2. Set JAVA_HOME:**
```bash
# Windows (System Properties → Environment Variables)
JAVA_HOME=C:\Program Files\Java\jdk-17

# Mac/Linux (~/.bashrc or ~/.zshrc)
export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home
export PATH=$JAVA_HOME/bin:$PATH
```

**3. Install Android SDK:**
```bash
# Option A: Install Android Studio (Easiest)
# Download from: https://developer.android.com/studio
# During setup, it will install SDK automatically

# Option B: Command Line Only
# Download SDK from: https://developer.android.com/studio#command-tools
# Extract and set ANDROID_HOME
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

**4. Accept Android Licenses:**
```bash
sdkmanager --licenses
# Type 'y' to accept all
```

---

## 🏗️ Build Commands

### Build Debug APK:
```bash
cd android
./gradlew assembleDebug      # Mac/Linux
gradlew assembleDebug        # Windows
```

### Build Release APK:
```bash
cd android
./gradlew assembleRelease    # Mac/Linux
gradlew assembleRelease      # Windows
```

### Clean and Rebuild:
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

---

## 📦 APK Information

| Property | Value |
|----------|-------|
| **App Name** | Lorme |
| **Package** | com.lorme.app |
| **Version** | 1.0.0 |
| **Min SDK** | 22 (Android 5.1) |
| **Target SDK** | 34 (Android 14) |
| **Architecture** | arm64-v8a, armeabi-v7a, x86_64 |
| **Size** | ~50-100 MB |

---

## 📥 Install on Android Device

### Option 1: USB Cable
1. Connect phone to computer
2. Enable USB Debugging on phone
3. Transfer APK file
4. Install on phone

### Option 2: Cloud Storage
1. Upload APK to Google Drive/Dropbox
2. Download on phone
3. Tap to install

### Option 3: Email
1. Email APK to yourself
2. Open email on phone
3. Download and install

### Enable Installation:
```
Settings → Security → Unknown Sources (Enable)

OR (Android 8+)

Settings → Apps → Special Access → Install Unknown Apps
→ Select your File Manager → Allow
```

---

## 🐛 Troubleshooting

### "Gradle build failed"
```bash
# Update Gradle
cd android
./gradlew wrapper --gradle-version=8.0

# Clean and rebuild
./gradlew clean
./gradlew assembleDebug
```

### "SDK not found"
```bash
# Set ANDROID_HOME
export ANDROID_HOME=$HOME/Android/Sdk

# Or install Android Studio
```

### "JAVA_HOME not set"
```bash
# Set JAVA_HOME
export JAVA_HOME=/path/to/java

# Verify
java -version
```

### "APK installation blocked"
- Enable "Unknown Sources" in Settings
- Disable Google Play Protect temporarily
- Check if APK is corrupted (rebuild)

### "Out of memory error"
```bash
# Increase Gradle memory
# Edit android/gradle.properties:
org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
```

---

## 🔐 Release Build (For Play Store)

### 1. Create Keystore:
```bash
keytool -genkey -v -keystore lorme-release-key.jks \
-keyalg RSA -keysize 2048 -validity 10000 \
-alias lorme-alias
```

### 2. Configure Signing:
Create `android/key.properties`:
```properties
storePassword=your_password
keyPassword=your_password
keyAlias=lorme-alias
storeFile=../lorme-release-key.jks
```

### 3. Update `android/app/build.gradle`:
```gradle
android {
    ...
    signingConfigs {
        release {
            def keystorePropertiesFile = rootProject.file("key.properties")
            def keystoreProperties = new Properties()
            if (keystorePropertiesFile.exists()) {
                keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
            }
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

### 4. Build Release:
```bash
./gradlew assembleRelease
```

### APK Location:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 📱 What's Included in the App

✅ Auto-reply rules with keywords  
✅ Scheduled messages  
✅ Quick reply shortcuts  
✅ Business hours automation  
✅ Response logging  
✅ Dark mode  
✅ 100% offline functionality  
✅ Local data storage  
✅ Privacy-first design  

---

## 🆘 Need Help?

### Common Issues & Solutions:

| Problem | Solution |
|---------|----------|
| Gradle sync failed | Check internet connection, retry |
| SDK not found | Install Android Studio |
| JAVA_HOME error | Set JAVA_HOME environment variable |
| Build failed | Run `./gradlew clean` first |
| APK won't install | Enable Unknown Sources |
| App crashes | Check Android version (need 5.1+) |

### Resources:
- [Capacitor Docs](https://capacitorjs.com)
- [Android Developer](https://developer.android.com)
- [Gradle Docs](https://gradle.org)

---

## ✅ Quick Checklist

Before building:
- [ ] Node.js installed
- [ ] Java JDK 17 installed
- [ ] Android SDK installed
- [ ] Web app built (`npm run build`)
- [ ] Capacitor synced (`npx cap sync android`)

After building:
- [ ] APK generated
- [ ] APK transferred to phone
- [ ] Unknown Sources enabled
- [ ] App installed successfully
- [ ] App opens without errors

---

**Happy Building! 🚀**

Version: 1.0.0  
Last Updated: 2026
