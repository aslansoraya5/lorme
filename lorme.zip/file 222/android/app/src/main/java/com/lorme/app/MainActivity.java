package com.lorme.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
